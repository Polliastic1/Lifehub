# Life Admin Hub

A personal life-admin app: connects to Gmail (read-only), extracts bills,
subscriptions, receipts, warranties, and travel, and surfaces them with reminders
and an assistant. Free tier + premium (Stripe). Security model: strongest
practical protection compatible with server-side email parsing (see Terms).

---

## ⚠️ Read before you push to a PUBLIC repo

`preview/index.html` has the sample document images **embedded** (base64). Some of
those images show real-looking identifiers — a passport number/MRZ, a card's full
number and security code, IDs. The card metadata is masked, but the **images
themselves are not**. If you push this to a public repo or enable GitHub Pages,
those images become publicly downloadable.

For a public demo, replace them with blurred/placeholder images first (ask and I
can generate a redacted `preview/`). For a private repo it's fine as-is.

---

## What's in here

```
backend/    FastAPI app — Gmail OAuth, KMS field-encryption, parser, review queue
frontend/   ConnectGmail.jsx (a component, not a full SPA)
preview/    Static mockup of the UI (GitHub Pages-ready)
docs/       Roadmap + free-vs-premium tiers
```

## What's functional today — honest status

| Piece | State |
|---|---|
| Static preview (`preview/index.html`) | ✅ Works as a hosted page immediately (it's a mockup — no real data/auth) |
| Backend locally (`docker-compose up`) | ✅ Runs end-to-end with a **dev** local KMS, no AWS needed |
| Gmail OAuth + encrypted token storage | ✅ Built; needs your Google OAuth credentials |
| Parser / review queue / reminders | ✅ Built; parser verified on a real receipt |
| Stripe billing | ⏳ Endpoint + webhook design specified, not yet coded |
| **User login (sessions)** | ❌ Placeholder only — the Connect-Gmail button needs real auth to work in a browser |
| Full production UI wired to backend | ❌ The working UI is your Replit/Base44 project; this repo is the engine |

So: **pushing to GitHub gives you the code and a hostable mockup.** A fully
functional public product additionally needs real login, deployment, and the
external services below.

## Run the backend locally (no AWS)

```bash
cd backend
cp .env.example .env
# generate a dev master key and put it in .env as LOCAL_KMS_MASTER_KEY:
python -c "import os,base64;print('LOCAL_KMS_MASTER_KEY='+base64.b64encode(os.urandom(32)).decode())"
# set KMS_PROVIDER=local, and your GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET
docker compose up --build
# API at http://localhost:8000  (docs at /docs)
```

Or without Docker: create a venv, `pip install -r requirements.txt`, run a local
Postgres, `python -m app.db.migrate`, then `uvicorn app.api.main:app --reload`.

Verify the parser: `cd backend && python -m app.parsing.eval`.

## Host the preview (GitHub Pages)

Push the repo, then in repo Settings → Pages, serve from `/preview` (or copy
`preview/index.html` to a `docs/` folder / `gh-pages` branch). Mind the public
exposure warning above.

## Going to production (the parts that aren't "just files")

- **Postgres** (managed, e.g. RDS) with the migrations applied by a schema-owner
  role; serve traffic with a separate RLS-bound app role.
- **AWS KMS**: set `KMS_PROVIDER=aws` and `KMS_KEY_ID`; give the app role
  `GenerateDataKey`/`Decrypt`. (The local KMS is dev-only.)
- **Google OAuth**: real client + your deployed redirect URI; restricted
  `gmail.readonly` scope requires Google verification + annual CASA before the
  public (non-test users) can connect.
- **Real session auth** behind `app/api/deps.py:current_user_id`.
- **Stripe**: implement `/billing/create-checkout-session` (trial_period_days: 7)
  and the webhook that owns subscription status.
- **Deploy** the API (container) somewhere with HTTPS; build/host the frontend.

See `docs/ROADMAP.md` for sequencing.

> This README and the in-app Terms are starting points, not legal advice. Have
> counsel review security/billing representations before launch.
